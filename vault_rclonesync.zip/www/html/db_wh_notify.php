<?php
if (!empty($_GET['challenge'])) {
  echo $_GET['challenge'];
  exit(0);
}

// Be sure to put in a restrictive entry in the sudoers file to allow www-data to run ONLY this shell script

$cmd = "sudo -u bshensky /home/bshensky/bin/vault_request_rclonesync.sh --rclone-args --cache-db-purge";
$output = shell_exec($cmd);
echo "<pre>" . $output . "</pre>";

